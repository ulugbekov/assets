/*************************************************************************************************
MaxMind Credit Card Fraud Detection API
Version: TSQL/1.0.1a
Programmed By: Shaun Hawkes <shawkes@ragingcreations.com>

Syntax:
	select [key], [value] from dbo.ccfdQuery(<maxmind license key>, <ip>, <city>, <state>, <zip>, <country>, <email>, <bin>, <phone>)

Returns:
	table([id] int, [key] varchar(255), [value] varchar(4096))
	ID=Order in which the items were returned in the original reply (1,2,3,4,etc)
	KEY=The name of the value returned (proxyScore,queriesRemaining,score,spamScore,etc)
	VALUE=The value of the KEY item

Example:
	select [key], [value] from dbo.ccfdQuery('YOURMAXMINDKEY', '192.168.1.1', 'Victoria', 'BC', 'V8V8V8', 'CA', 'somewhere.com', '424242', '555-555')

Notes:
	I have included several helper functions to assist in getting information in the correct format for MaxMind
	-dbo.ccfdFormatEmail('someone@somewhere.com') - Extracts the domain from an email address (somewhere.com)
	-dbo.ccfdFormatBin('4242-4242-4242-4242') - Removes all non-numeric values and returns first 6 digits (424242)
	-dbo.ccfdFormatPhone('555-555-5555') - Removed all non-numeric values and returns first 6 digits as 2 3 character strings separated by a '-' (555-555)

Changes:
        Add minfraud3.maxmind.com to the server list
*************************************************************************************************/

/****** Object:  User Defined Function dbo.DoubleSplit    Script Date: 1/4/2006 10:27:25 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[DoubleSplit]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[DoubleSplit]
GO

/****** Object:  User Defined Function dbo.split    Script Date: 1/4/2006 10:27:25 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[split]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[split]
GO

/****** Object:  User Defined Function dbo.vbRegExpReplace    Script Date: 1/4/2006 10:27:25 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[vbRegExpReplace]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[vbRegExpReplace]
GO

/****** Object:  User Defined Function dbo.StripNonAlphaNum    Script Date: 1/4/2006 10:27:25 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[StripNonAlphaNum]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[StripNonAlphaNum]
GO

/****** Object:  User Defined Function dbo.StripNonNum    Script Date: 1/4/2006 10:27:25 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[StripNonNum]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[StripNonNum]
GO

/****** Object:  User Defined Function dbo.getHttp    Script Date: 1/4/2006 10:54:31 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[getHttp]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[getHttp]
GO

/****** Object:  User Defined Function dbo.ccfdQuery    Script Date: 1/4/2006 10:27:25 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ccfdQuery]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[ccfdQuery]
GO

/****** Object:  User Defined Function dbo.ccfdFormatEmail    Script Date: 1/4/2006 10:27:25 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ccfdFormatEmail]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[ccfdFormatEmail]
GO

/****** Object:  User Defined Function dbo.ccfdFormatBin    Script Date: 1/4/2006 10:27:25 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ccfdFormatBin]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[ccfdFormatBin]
GO

/****** Object:  User Defined Function dbo.ccfdFormatPhone    Script Date: 1/4/2006 10:27:25 AM ******/
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ccfdFormatPhone]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[ccfdFormatPhone]
GO

/****** Object:  User Defined Function dbo.DoubleSplit    Script Date: 1/4/2006 10:17:27 AM ******/
create FUNCTION [dbo].[DoubleSplit] (@inString varchar(8000), @separator varchar(4000), @separator2 varchar(4000))
RETURNS @return table([id] int, [key] varchar(4000), [value] varchar(4000))
AS  
BEGIN 
	Declare @pos Int
	Declare @counter Int
	
	Set @counter = 0
	Set @inString = @inString + @separator
	
	While PatIndex('%' + @separator + '%' , @inString) <> 0 
	Begin
		DECLARE @match varchar(8000)
		DECLARE @key varchar(8000)
		DECLARE @value varchar(8000)
	
		Set @pos = PatIndex('%' + @separator + '%' , @inString)
		Set @match = Left(@inString, @pos - 1)

		if(PatIndex('%' + @separator2 + '%' , @match) <> 0)
		BEGIN
		Declare @pos2 Int
			Set @pos2 = PatIndex('%' + @separator2 + '%' , @match)
			Set @key = Left(@match, @pos2 - 1)
			Set @value = Stuff(@match, 1, @pos2, '')
		END
		else
			set @key = @match 
		
		insert into @return([id],[key],[value]) values(@counter,@key,@value)
	
		Set @inString = Stuff(@inString, 1, @pos, '')
		Set @counter = @counter+1
	End

	RETURN
END

GO

/****** Object:  User Defined Function dbo.split    Script Date: 1/4/2006 10:17:28 AM ******/
CREATE FUNCTION [dbo].[split] (@inString varchar(8000), @separator varchar(8000))
RETURNS @return table([id] int, [value] varchar(8000))
AS  
BEGIN 
	Declare @pos Int
	Declare @counter Int
	
	Set @counter = 0
	Set @inString = @inString + @separator
	
	While PatIndex('%' + @separator + '%' , @inString) <> 0 
	Begin
		DECLARE @value varchar(8000)
	
		Set @pos = PatIndex('%' + @separator + '%' , @inString)
		Set @value = Left(@inString, @pos - 1)
		
		insert into @return([id],[value]) values(@counter,@value)
	
		Set @inString = Stuff(@inString, 1, @pos, '')
		Set @counter = @counter+1
	End

	RETURN
END

GO

/****** Object:  User Defined Function dbo.vbRegExpReplace    Script Date: 1/4/2006 10:17:28 AM ******/
create FUNCTION [dbo].[vbRegExpReplace](@source varchar(4096), @regexp varchar(1024), @replace varchar(1024))
RETURNS varchar(8000)
AS
BEGIN
	DECLARE @hr integer
	DECLARE @objRegExp integer
	DECLARE @results bit
	DECLARE @ret varchar(8000)
	DECLARE @func varchar(8000)
	
	SET @func = 'VBScript.RegExp'
	EXEC @hr = sp_OACreate @func, @objRegExp OUTPUT
	IF @hr <> 0
		RETURN @source

	SET @func = 'Pattern'
	EXEC @hr = sp_OASetProperty @objRegExp, @func, @regexp
	IF @hr <> 0
		RETURN @source

	SET @func = 'Global'
	EXEC @hr = sp_OASetProperty @objRegExp, @func, true
	IF @hr <> 0
		RETURN @source

	SET @func = 'IgnoreCase'
	EXEC @hr = sp_OASetProperty @objRegExp, @func, true
	IF @hr <> 0
		RETURN @source

	SET @func = 'Replace'
	EXEC @hr = sp_OAMethod @objRegExp, @func, @ret OUTPUT, @source, @replace
	IF @hr <> 0
		RETURN @source

	EXEC @hr = sp_OADestroy @objRegExp
	IF @hr <> 0
		RETURN @source

	RETURN @ret
END

GO

/****** Object:  User Defined Function dbo.StripNonAlphaNum    Script Date: 1/4/2006 10:17:30 AM ******/
create FUNCTION [dbo].[StripNonAlphaNum](@string varchar(8000))
RETURNS varchar(8000)
AS  
BEGIN 
	return dbo.vbRegExpReplace(@string,'[^0-9a-z]','')
END

GO

/****** Object:  User Defined Function dbo.StripNonNum    Script Date: 1/4/2006 10:17:30 AM ******/
create FUNCTION [dbo].[StripNonNum](@string varchar(8000))
RETURNS varchar(8000)
AS  
BEGIN 
	return dbo.vbRegExpReplace(@string,'[^0-9/.]','')
END

GO

/****** Object:  User Defined Function dbo.getHttp    Script Date: 1/4/2006 10:54:31 AM ******/
CREATE FUNCTION dbo.getHttp(@method varchar(4), @url varchar(2048), @data varchar(4096))
RETURNS @ret table([code] int, [error] varchar(1024), [head] varchar(1024), [html] varchar(4096))
AS  
BEGIN 
	Declare @Return int
	Declare @Object int
	Declare @agent varchar(255)

	set @agent = 'TSQL-Http 1.0.0a'

	Declare @code int
	Declare @error varchar(1024)
	Declare @head varchar(1024)
	Declare @html varchar(4096)

	Declare @func varchar(8000)

	if(@method='GET')
	BEGIN
		set @url = @url+'?'+@data
		set @data = ''
	END

	SET @func = 'WinHttp.WinHttpRequest.5.1'
	EXEC @Return = sp_oacreate @func, @Object Output
--	EXEC sp_OAGetErrorInfo @object

	SET @func = 'Open("POST", "'+@URL+'", false)'
	EXEC @Return = sp_oamethod @Object, @func, null
--	EXEC sp_OAGetErrorInfo @object

	SET @func = 'setRequestHeader("User-Agent", "'+@agent+'")'
	EXEC @Return = sp_oamethod @Object, @func, null 
--	EXEC sp_OAGetErrorInfo @object

	if(@method='POST')
	BEGIN
		SET @func = 'setRequestHeader("Content-Type", "application/x-www-form-urlencoded")'
		EXEC @Return = sp_oamethod @Object, @func, null
		--EXEC sp_OAGetErrorInfo @object
	END

	SET @func = 'Send("' + @Data + '")'
	EXEC @Return = sp_oamethod @Object, @func, null
--	EXEC sp_OAGetErrorInfo @object

	SET @func = 'GetAllResponseHeaders'
	EXEC @Return = sp_oagetproperty @Object, @func, @head OUT
--	EXEC sp_OAGetErrorInfo @Object
	set @head = isNull(@head,'')

	SET @func = 'responseText'
	Exec @Return = sp_oagetproperty @Object, @func, @html OUT
--	EXEC sp_OAGetErrorInfo @Object
	set @html = isNull(@html,'')

	/* Quick Error Checks */
	if(@head='')
		select @code = 500, @error = 'Connection Error, no header returned'

	
	if(@html='')
		select @code = 200, @error = 'Connection success, nothing returned'
	else if(charindex('HTTP Error 401',@html)>0)
		select @code = 401, @error = 'Invalid authorization'
	else if(charindex('HTTP Error 404',@html)>0)
		select @code = 404, @error = 'File not found'
	else
		select @code = 200, @error = 'Connection success'

	Exec sp_oadestroy @Object

	insert @ret
		select @code, @error, @head, @html

	return
END 

GO

/****** Object:  User Defined Function dbo.ccfdQuery    Script Date: 1/4/2006 10:17:30 AM ******/
create FUNCTION [dbo].[ccfdQuery](@ccfdLicenseKey varchar(255), @ip varchar(20), @city varchar(255), @region varchar(255), @postal varchar(255), @country varchar(2), @domain varchar(1024), @bin varchar(255), @custPhone varchar(255))  
RETURNS @ret table([id] int, [key] varchar(255), [value] varchar(4096))
AS  
BEGIN 
	/* Config values */
	DECLARE @ccfdServerList varchar(1024), @ccfdAPIVersion varchar(255), @ccfdURL varchar(255), @ccfdSecure int, @ccfdTimeout int, @ccfdDebug int
	SET @ccfdServerList		= 'minfraud1.maxmind.com,minfraud2.maxmind.com,minfraud3.maxmind.com'	--Server list
	SET @ccfdAPIVersion		= 'TSQL/1.0.1a'				--Version of the API
	SET @ccfdURL			= 'app/ccv2r'				--URL of the webservice
	SET @ccfdSecure			= 1					--Use HTTPS By Default
	SET @ccfdTimeout		= 5					--Set default connection timeout to 5 seconds. /* Not currently used */
	SET @ccfdDebug			= 0					--Enable/Disable debugging mode. /* Not currently used */

	DECLARE @strScheme varchar(10)
	if(@ccfdSecure>0)
		SET @strScheme = 'https://'
	else
		SET @strScheme = 'http://'

	DECLARE @strQuery varchar(8000)
	SET @strQuery = ''
	SET @strQuery = @strQuery + 'i=' + @ip + '&'
	SET @strQuery = @strQuery + 'city=' + @city + '&'
	SET @strQuery = @strQuery + 'region=' + @region + '&'
	SET @strQuery = @strQuery + 'postal=' + @postal + '&'
	SET @strQuery = @strQuery + 'country=' + @country + '&'
	SET @strQuery = @strQuery + 'domain=' + @domain + '&'
	SET @strQuery = @strQuery + 'bin=' + @bin + '&'
	SET @strQuery = @strQuery + 'custPhone=' + @custPhone + '&'
	SET @strQuery = @strQuery + 'license_key=' + @ccfdLicenseKey + '&'
	SET @strQuery = @strQuery + 'clientAPI=' + @ccfdAPIVersion + '&'

	/* Loop Through Server Values */
	DECLARE myCursor CURSOR FOR
		select value from dbo.split(@ccfdServerList,',')
	
	DECLARE @strServer varchar(255)
	
	OPEN myCursor
	FETCH NEXT FROM myCursor INTO @strServer
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @strUrl varchar(8000)
		SET @strUrl = @strScheme + @strServer + '/' + @ccfdURL
	
		DECLARE @code int, @error varchar(1024), @head varchar(4096), @html varchar(8000)
		SELECT @code=[code],@error=[error],@head=[head],@html=[html] from dbo.getHttp('GET', @strUrl, @strQuery)
	
		if(@code=200)
		BEGIN
			insert @ret
				select * from dbo.DoubleSplit(@html, ';', '=') where [key] is not null and [key] != ''
	
			DECLARE @score float
			select @score=isNull([value],-1) from @ret where [key]='score'
	
			if(@score>=0)
				BREAK
		END

		FETCH NEXT FROM myCursor INTO @strServer

		/* Insert HTTP Error Tracking Message */
		if(@@FETCH_STATUS != 0)
		BEGIN
			DECLARE @counter int
			select @counter = isNull(max([id]),-1)+1 from @ret

			insert @ret
				select @counter,'score','5.00' --Return Default Score of 5 if none returned
				UNION
				select @counter+1,'http_error',@code
				UNION
				select @counter+2,'http_error_msg',@error
		END
	END
	
	CLOSE myCursor
	DEALLOCATE myCursor

	RETURN
END

GO

/****** Object:  User Defined Function dbo.ccfdFormatEmail    Script Date: 1/4/2006 10:17:31 AM ******/
create FUNCTION [dbo].[ccfdFormatEmail](@email varchar(1024))
RETURNS varchar(1024)
AS
BEGIN 
RETURN
(
	select top 1 value from dbo.split(@email,'@') order by [id] desc
)
END

GO

/****** Object:  User Defined Function dbo.ccfdFormatBin    Script Date: 1/4/2006 10:17:31 AM ******/
create FUNCTION [dbo].[ccfdFormatBin](@bin varchar(255))
RETURNS varchar(255)
AS
BEGIN
	DECLARE @ret varchar(255)
	SET @ret = dbo.StripNonAlphaNum(@bin)
	
	if(len(@ret)>6)
		set @ret = left(@ret, 6)

	return @ret
END

GO

/****** Object:  User Defined Function dbo.ccfdFormatPhone    Script Date: 1/4/2006 10:17:31 AM ******/
create FUNCTION [dbo].[ccfdFormatPhone](@bin varchar(255))
RETURNS varchar(255)
AS
BEGIN
	DECLARE @ret varchar(255)
	SET @ret = dbo.StripNonAlphaNum(@bin)
	
	if(len(@ret)>6)
	BEGIN
		set @ret = left(@ret, 6)
		set @ret = left(@ret, 3)+'-'+right(@ret, 3)
	END

	return @ret
END

GO
